class BaseLayer(object):
    def __init__(self):
        self.trainable = False
        self.testing_phase = False
        
        
        